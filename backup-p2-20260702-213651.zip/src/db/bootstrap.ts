import fs from "node:fs";
import path from "node:path";
import { BUILTIN_AGENTS } from "@/db/builtin-agents";
import { getDataDir, getDatabase } from "@/db/client";
import { recoverOrphanedRuns } from "@/server/run-recovery";
import { newConversationId, newWorkspaceId } from "@/shared/ids";

let bootstrapped = false;

export function ensureDatabase() {
  if (bootstrapped) return;
  const db = getDatabase();

  db.exec(`
    CREATE TABLE IF NOT EXISTS agents (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      avatar TEXT NOT NULL,
      description TEXT NOT NULL,
      capabilities TEXT NOT NULL,
      system_prompt TEXT NOT NULL,
      adapter_name TEXT NOT NULL,
      model_provider TEXT,
      model_id TEXT,
      api_key TEXT,
      api_base_url TEXT,
      tool_names TEXT NOT NULL,
      is_builtin INTEGER NOT NULL DEFAULT 0,
      is_orchestrator INTEGER NOT NULL DEFAULT 0,
      supports_vision INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      mode TEXT NOT NULL,
      agent_ids TEXT NOT NULL,
      pinned_message_ids TEXT NOT NULL,
      archived INTEGER NOT NULL DEFAULT 0,
      fs_write_approval_mode TEXT NOT NULL DEFAULT 'review',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      agent_id TEXT REFERENCES agents(id),
      run_id TEXT,
      parts TEXT NOT NULL,
      status TEXT NOT NULL,
      mentioned_agent_ids TEXT NOT NULL,
      parent_message_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS artifacts (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      created_by_agent_id TEXT REFERENCES agents(id),
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      parent_artifact_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workspaces (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
      mode TEXT NOT NULL DEFAULT 'sandbox',
      root_path TEXT NOT NULL,
      bound_path TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS attachments (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      kind TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      size INTEGER NOT NULL,
      mime_type TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS agent_runs (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      agent_id TEXT NOT NULL REFERENCES agents(id),
      trigger_message_id TEXT,
      parent_run_id TEXT,
      status TEXT NOT NULL,
      stage TEXT,
      error TEXT,
      usage TEXT,
      interrupted INTEGER NOT NULL DEFAULT 0,
      error_category TEXT,
      retryable INTEGER NOT NULL DEFAULT 0,
      started_at INTEGER NOT NULL,
      finished_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orchestration_task_results (
      id TEXT PRIMARY KEY,
      orchestrator_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      conversation_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      title TEXT,
      status TEXT NOT NULL,
      summary TEXT,
      child_run_id TEXT,
      attempt INTEGER NOT NULL DEFAULT 1,
      error_category TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pending_approvals (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      run_id TEXT NOT NULL,
      approval_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      payload_json TEXT NOT NULL,
      resolved_by TEXT,
      resolved_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orchestration_plans (
      id TEXT PRIMARY KEY,
      orchestrator_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      conversation_id TEXT NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      plan_json TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      user_feedback TEXT,
      stage_at_creation TEXT,
      resumed_from_run_id TEXT,
      created_at INTEGER NOT NULL,
      resolved_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS orchestration_output_bindings (
      orchestrator_run_id TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      producer_task_id TEXT NOT NULL,
      output_key TEXT NOT NULL,
      artifact_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      PRIMARY KEY (plan_id, producer_task_id, output_key)
    );

    CREATE TABLE IF NOT EXISTS orchestration_conflicts (
      id TEXT PRIMARY KEY,
      orchestrator_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      plan_id TEXT NOT NULL,
      path TEXT NOT NULL,
      wave INTEGER NOT NULL,
      contributors_json TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'detected',
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS context_compaction_jobs (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      base_summary_id TEXT,
      previous_job_id TEXT,
      result_summary_id TEXT,
      source_start_message_id TEXT NOT NULL,
      source_end_message_id TEXT NOT NULL,
      source_message_count INTEGER NOT NULL,
      chunk_count INTEGER NOT NULL DEFAULT 0,
      completed_chunk_count INTEGER NOT NULL DEFAULT 0,
      model_provider TEXT NOT NULL,
      model_id TEXT NOT NULL,
      attempt INTEGER NOT NULL DEFAULT 1,
      error_category TEXT,
      error TEXT,
      retryable INTEGER NOT NULL DEFAULT 0,
      started_at INTEGER,
      finished_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS conversation_context_summaries (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      summary TEXT NOT NULL,
      covered_until_message_id TEXT NOT NULL,
      covered_until_created_at INTEGER NOT NULL,
      source_message_count INTEGER NOT NULL,
      token_estimate INTEGER NOT NULL,
      model_provider TEXT,
      model_id TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      id TEXT PRIMARY KEY,
      anthropic_api_key TEXT,
      anthropic_base_url TEXT,
      openai_api_key TEXT,
      deepseek_api_key TEXT,
      ark_api_key TEXT,
      companion_mode TEXT NOT NULL DEFAULT 'off',
      mobile_device_token TEXT,
      deployment_publish_enabled INTEGER NOT NULL DEFAULT 0,
      deployment_publish_dir TEXT,
      deployment_public_base_url TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    -- P1: Evidence-aware Context Engineering tables

    CREATE TABLE IF NOT EXISTS task_attempts (
      id TEXT PRIMARY KEY,
      conductor_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      conversation_id TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      plan_revision INTEGER NOT NULL DEFAULT 0,
      task_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      child_run_id TEXT,
      attempt INTEGER NOT NULL,
      context_snapshot_id TEXT,
      execution_status TEXT NOT NULL DEFAULT 'queued',
      verification_status TEXT NOT NULL DEFAULT 'not_started',
      failure_context_json TEXT,
      started_at INTEGER,
      finished_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      UNIQUE(conductor_run_id, plan_id, task_id, attempt)
    );

    CREATE TABLE IF NOT EXISTS task_context_snapshots (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      conductor_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      plan_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      attempt_id TEXT NOT NULL REFERENCES task_attempts(id) ON DELETE CASCADE,
      policy_version TEXT NOT NULL,
      schema_version INTEGER NOT NULL,
      envelope_json TEXT NOT NULL,
      manifest_json TEXT NOT NULL,
      token_estimate INTEGER NOT NULL DEFAULT 0,
      required_token_estimate INTEGER NOT NULL DEFAULT 0,
      omitted_token_estimate INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS task_evidence (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      conductor_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      plan_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      attempt_id TEXT NOT NULL REFERENCES task_attempts(id) ON DELETE CASCADE,
      child_run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
      context_snapshot_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'valid',
      trust_level TEXT NOT NULL DEFAULT 'verified',
      source_kind TEXT NOT NULL,
      source_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      subject_id TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      content_hash TEXT,
      invalidated_at INTEGER,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS criterion_verdicts (
      id TEXT PRIMARY KEY,
      attempt_id TEXT NOT NULL REFERENCES task_attempts(id) ON DELETE CASCADE,
      criterion_id TEXT NOT NULL,
      validator_type TEXT NOT NULL,
      status TEXT NOT NULL,
      evidence_ids_json TEXT NOT NULL DEFAULT '[]',
      reason TEXT NOT NULL,
      checked_at INTEGER NOT NULL,
      UNIQUE(attempt_id, criterion_id)
    );

    -- P2: Fact Registry tables

    CREATE TABLE IF NOT EXISTS conversation_fact_definitions (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL
        REFERENCES conversations(id) ON DELETE CASCADE,
      canonical_key TEXT NOT NULL,
      namespace TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      property_name TEXT NOT NULL,
      value_type TEXT NOT NULL,
      update_policy TEXT NOT NULL DEFAULT 'replace',
      description TEXT NOT NULL,
      aliases_json TEXT NOT NULL DEFAULT '[]',
      applicable_task_tags_json TEXT NOT NULL DEFAULT '[]',
      applicable_agent_roles_json TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'active',
      origin TEXT NOT NULL DEFAULT 'conversation',
      proposed_by_agent_id TEXT,
      source_message_id TEXT,
      merged_into_definition_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      UNIQUE(conversation_id, canonical_key)
    );

    CREATE TABLE IF NOT EXISTS conversation_facts (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL
        REFERENCES conversations(id) ON DELETE CASCADE,
      definition_id TEXT NOT NULL,
      canonical_key TEXT NOT NULL,
      value_json TEXT NOT NULL,
      value_type TEXT NOT NULL,
      status TEXT NOT NULL,
      trust_level TEXT NOT NULL,
      confidence REAL NOT NULL,
      resolution_method TEXT NOT NULL,
      source_type TEXT NOT NULL,
      source_id TEXT NOT NULL,
      supersedes_fact_id TEXT,
      invalidated_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS conversation_fact_sources (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL
        REFERENCES conversations(id) ON DELETE CASCADE,
      fact_id TEXT NOT NULL
        REFERENCES conversation_facts(id) ON DELETE CASCADE,
      source_type TEXT NOT NULL,
      source_id TEXT NOT NULL,
      source_excerpt TEXT,
      created_at INTEGER NOT NULL,
      UNIQUE(fact_id, source_type, source_id)
    );
  `);

  migrateLegacyTables();
  createIndexes();
  createMessageSearchIndex();
  seedBuiltinAgents();
  seedAppSettings();
  seedWelcomeConversation();

  // P1: Recover orphaned runs from previous process (must be after tables exist)
  bootstrapped = true;
  recoverOrphanedRuns();
}

function createMessageSearchIndex() {
  const db = getDatabase();
  try {
    db.exec(`
      CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
        content,
        tokenize = 'trigram'
      );

      CREATE TRIGGER IF NOT EXISTS messages_fts_ai
      AFTER INSERT ON messages
      WHEN new.status != 'streaming'
      BEGIN
        INSERT OR REPLACE INTO messages_fts(rowid, content)
        SELECT new.rowid, GROUP_CONCAT(json_extract(value, '$.content'), ' ')
        FROM json_each(new.parts)
        WHERE json_extract(value, '$.type') = 'text'
        HAVING COUNT(*) > 0;
      END;

      CREATE TRIGGER IF NOT EXISTS messages_fts_au
      AFTER UPDATE ON messages
      BEGIN
        DELETE FROM messages_fts WHERE rowid = old.rowid;
        INSERT OR REPLACE INTO messages_fts(rowid, content)
        SELECT new.rowid, GROUP_CONCAT(json_extract(value, '$.content'), ' ')
        FROM json_each(new.parts)
        WHERE new.status != 'streaming'
          AND json_extract(value, '$.type') = 'text'
        HAVING COUNT(*) > 0;
      END;

      CREATE TRIGGER IF NOT EXISTS messages_fts_ad
      AFTER DELETE ON messages
      BEGIN
        DELETE FROM messages_fts WHERE rowid = old.rowid;
      END;

      INSERT OR REPLACE INTO messages_fts(rowid, content)
      SELECT m.rowid, GROUP_CONCAT(json_extract(j.value, '$.content'), ' ')
      FROM messages m, json_each(m.parts) AS j
      WHERE m.status != 'streaming'
        AND json_extract(j.value, '$.type') = 'text'
      GROUP BY m.rowid;
    `);
  } catch {
    // Search service falls back to JSON text-part LIKE queries when FTS5 is unavailable.
  }
}

export function resetBootstrapForTests() {
  bootstrapped = false;
}

function migrateLegacyTables() {
  ensureColumn("agents", "avatar", "TEXT NOT NULL DEFAULT '🤖'");
  ensureColumn("agents", "capabilities", "TEXT NOT NULL DEFAULT '[]'");
  ensureColumn("agents", "api_key", "TEXT");
  ensureColumn("agents", "api_base_url", "TEXT");
  ensureColumn("agents", "supports_vision", "INTEGER NOT NULL DEFAULT 0");

  ensureColumn("conversations", "archived", "INTEGER NOT NULL DEFAULT 0");

  ensureColumn("agent_runs", "error", "TEXT");
  ensureColumn("agent_runs", "started_at", "INTEGER NOT NULL DEFAULT 0");
  ensureColumn("agent_runs", "finished_at", "INTEGER");

  ensureColumn("app_settings", "anthropic_base_url", "TEXT");
  ensureColumn("app_settings", "companion_mode", "TEXT NOT NULL DEFAULT 'off'");
  ensureColumn("app_settings", "mobile_device_token", "TEXT");
  ensureColumn("app_settings", "deployment_publish_enabled", "INTEGER NOT NULL DEFAULT 0");
  ensureColumn("app_settings", "deployment_publish_dir", "TEXT");
  ensureColumn("app_settings", "deployment_public_base_url", "TEXT");

  // P1: Orchestration task results — verification status columns
  try { getDatabase().exec("ALTER TABLE orchestration_task_results ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'not_started'"); } catch { /* already exists */ }
  try { getDatabase().exec("ALTER TABLE orchestration_task_results ADD COLUMN verified_attempt_id TEXT"); } catch { /* already exists */ }

  getDatabase().exec(`
    UPDATE agent_runs SET started_at = created_at WHERE started_at = 0;
  `);
}

function createIndexes() {
  const db = getDatabase();
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_conv_updated ON conversations(updated_at);
    CREATE INDEX IF NOT EXISTS idx_messages_conv_created ON messages(conversation_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_artifacts_conv ON artifacts(conversation_id);
    CREATE INDEX IF NOT EXISTS idx_attachments_conv ON attachments(conversation_id);
    CREATE INDEX IF NOT EXISTS idx_runs_parent ON agent_runs(parent_run_id);
    CREATE INDEX IF NOT EXISTS idx_context_summaries_conv_created
      ON conversation_context_summaries(conversation_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_orch_task_results_run
      ON orchestration_task_results(orchestrator_run_id);
    CREATE INDEX IF NOT EXISTS idx_pending_approvals_conv
      ON pending_approvals(conversation_id, status);
    CREATE INDEX IF NOT EXISTS idx_pending_approvals_run
      ON pending_approvals(run_id);

    CREATE INDEX IF NOT EXISTS idx_orch_plans_run ON orchestration_plans(orchestrator_run_id);
    CREATE INDEX IF NOT EXISTS idx_orch_bindings_plan ON orchestration_output_bindings(plan_id);
    CREATE INDEX IF NOT EXISTS idx_orch_conflicts_run ON orchestration_conflicts(orchestrator_run_id);

    CREATE INDEX IF NOT EXISTS idx_compaction_jobs_conversation
      ON context_compaction_jobs(conversation_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_compaction_jobs_status
      ON context_compaction_jobs(status, updated_at);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_compaction_jobs_active
      ON context_compaction_jobs(conversation_id)
      WHERE status IN ('queued', 'running');

    -- P1: Evidence-aware indexes
    CREATE INDEX IF NOT EXISTS idx_task_evidence_attempt
      ON task_evidence(attempt_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_task_evidence_subject
      ON task_evidence(subject_type, subject_id, status);
    CREATE INDEX IF NOT EXISTS idx_task_evidence_task
      ON task_evidence(conductor_run_id, plan_id, task_id);
    CREATE INDEX IF NOT EXISTS idx_task_attempts_run
      ON task_attempts(conductor_run_id, task_id);
    CREATE INDEX IF NOT EXISTS idx_context_snapshots_attempt
      ON task_context_snapshots(attempt_id);

    -- P2: Fact Registry indexes
    CREATE INDEX IF NOT EXISTS idx_conversation_facts_active
      ON conversation_facts(conversation_id, canonical_key, status);
    CREATE INDEX IF NOT EXISTS idx_conversation_facts_source
      ON conversation_facts(source_type, source_id);
    CREATE INDEX IF NOT EXISTS idx_conversation_fact_definitions_lookup
      ON conversation_fact_definitions(conversation_id, namespace, entity_type, property_name);
  `);

  // P1: Migration for existing DBs that may lack the new columns/table
  try { db.exec(`ALTER TABLE agent_runs ADD COLUMN stage TEXT`); } catch { /* already exists */ }
  try { db.exec(`ALTER TABLE agent_runs ADD COLUMN interrupted INTEGER NOT NULL DEFAULT 0`); } catch { /* already exists */ }
  try { db.exec(`ALTER TABLE agent_runs ADD COLUMN error_category TEXT`); } catch { /* already exists */ }
  try { db.exec(`ALTER TABLE agent_runs ADD COLUMN retryable INTEGER NOT NULL DEFAULT 0`); } catch { /* already exists */ }
  try { db.exec(`ALTER TABLE conversations ADD COLUMN pinned_at INTEGER`); } catch { /* already exists */ }
  ensureColumn("context_compaction_jobs", "previous_job_id", "TEXT");
}

function seedBuiltinAgents() {
  const db = getDatabase();
  const now = Date.now();
  const insert = db.prepare(`
    INSERT OR IGNORE INTO agents (
      id, name, avatar, description, capabilities, system_prompt, adapter_name,
      model_provider, model_id, api_key, api_base_url, tool_names, is_builtin,
      is_orchestrator, supports_vision, created_at, updated_at
    ) VALUES (
      @id, @name, @avatar, @description, @capabilities, @systemPrompt, @adapterName,
      @modelProvider, @modelId, @apiKey, @apiBaseUrl, @toolNames, @isBuiltin,
      @isOrchestrator, @supportsVision, @createdAt, @updatedAt
    )
  `);

  for (const agent of BUILTIN_AGENTS) {
    const { isConductor: _conductor, ...rest } = agent as unknown as Record<string, unknown>;
    insert.run({
      ...rest,
      capabilities: JSON.stringify(agent.capabilities),
      toolNames: JSON.stringify(agent.toolNames),
      isBuiltin: agent.isBuiltin ? 1 : 0,
      isOrchestrator: agent.isOrchestrator ? 1 : 0,
      supportsVision: agent.supportsVision ? 1 : 0,
      createdAt: now,
      updatedAt: now
    });
  }
}

function seedAppSettings() {
  const now = Date.now();
  getDatabase()
    .prepare(
      `
        INSERT OR IGNORE INTO app_settings (
          id, companion_mode, deployment_publish_enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?)
      `
    )
    .run("singleton", "off", 0, now, now);
}

function seedWelcomeConversation() {
  const db = getDatabase();
  const count = db.prepare("SELECT COUNT(*) AS count FROM conversations").get() as { count: number };
  if (count.count > 0) return;

  const now = Date.now();
  const conversationId = newConversationId();
  const workspaceId = newWorkspaceId();
  const workspaceRoot = path.join(getDataDir(), "workspaces", conversationId);
  fs.mkdirSync(workspaceRoot, { recursive: true });

  db.prepare(`
    INSERT INTO conversations (
      id, title, mode, agent_ids, fs_write_approval_mode,
      pinned_message_ids, archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    conversationId,
    "Agent-Conference MVP 群聊",
    "group",
    JSON.stringify(["ag_mock_orchestrator", "ag_pm", "ag_designer", "ag_mock_builder", "ag_reviewer"]),
    "auto",
    JSON.stringify([]),
    0,
    now,
    now
  );

  db.prepare(`
    INSERT INTO workspaces (
      id, conversation_id, mode, root_path, bound_path, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(workspaceId, conversationId, "sandbox", workspaceRoot, null, now, now);
}

function ensureColumn(tableName: string, columnName: string, definition: string) {
  const columns = getDatabase().prepare(`PRAGMA table_info(${tableName})`).all() as Array<{ name: string }>;
  if (columns.some((column) => column.name === columnName)) return;
  getDatabase().exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
}
